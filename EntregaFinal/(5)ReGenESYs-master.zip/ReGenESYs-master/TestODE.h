/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   TestODE.h
 * Author: rlcancian
 *
 * Created on 26 de Setembro de 2019, 13:00
 */

#ifndef TESTODE_H
#define TESTODE_H

#include "BaseConsoleGenesysApplication.h"

class TestODE : public BaseConsoleGenesysApplication {
public:
    TestODE();
public:
    virtual int main(int argc, char** argv) ;
};

#endif /* TESTODE_H */

