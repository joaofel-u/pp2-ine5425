/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   TestSeparate.h
 * Author: joaofel-u
 *
 * Created on 20 de setembro de 2019, 15:31
 */

#ifndef TESTSEPARATE_H
#define TESTSEPARATE_H

#include "BaseConsoleGenesysApplication.h"

class TestSeparate: public BaseConsoleGenesysApplication {
public:
    TestSeparate();
public:
    virtual int main(int argc, char** argv);
};

#endif /* TESTSEPARATE_H */

