/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   SlidingWindowModel.h
 * Author: joafel-u
 *
 * Created on 11 de setembro de 2019, 08:25
 */

#ifndef SLIDINGWINDOWMODEL_H
#define SLIDINGWINDOWMODEL_H

#include "BaseConsoleGenesysApplication.h"

class SlidingWindowModel: public BaseConsoleGenesysApplication {
public:
    SlidingWindowModel();
public:
    virtual int main(int argc, char** argv);
};

#endif /* SLIDINGWINDOWMODEL_H */

