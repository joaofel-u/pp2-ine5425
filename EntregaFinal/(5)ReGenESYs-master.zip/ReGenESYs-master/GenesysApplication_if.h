/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   GenesysApplication_if.h
 * Author: rafael.luiz.cancian
 *
 * Created on 2 de Outubro de 2018, 19:14
 */

#ifndef GENESYSAPPLICATION_IF_H
#define GENESYSAPPLICATION_IF_H

class GenesysApplication_if {
public:
    virtual int main(int argc, char** argv) = 0;
};

#endif /* GENESYSAPPLICATION_IF_H */

