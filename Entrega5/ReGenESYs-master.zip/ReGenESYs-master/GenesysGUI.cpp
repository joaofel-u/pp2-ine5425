/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   GenesysGUI.cpp
 * Author: rafael.luiz.cancian
 * 
 * Created on 23 de Maio de 2019, 13:03
 */

#include "GenesysGUI.h"

GenesysGUI::GenesysGUI() {
}

GenesysGUI::GenesysGUI(const GenesysGUI& orig) {
}

GenesysGUI::~GenesysGUI() {
}

int GenesysGUI::main(int argc, char** argv) {
    return 0;
}
