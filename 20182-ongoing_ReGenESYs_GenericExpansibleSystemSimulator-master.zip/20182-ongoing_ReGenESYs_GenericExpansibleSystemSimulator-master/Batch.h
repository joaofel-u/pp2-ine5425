/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Batch.h
 * Author: rlcancian
 *
 * Created on 03 de Junho de 2019, 15:14
 */

#ifndef BATCH_H
#define BATCH_H

class Batch {
public:
    Batch();
    Batch(const Batch& orig);
    virtual ~Batch();
private:

};

#endif /* BATCH_H */

