/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ModelComponentManager_if.h
 * Author: rafael.luiz.cancian
 *
 * Created on 22 de Novembro de 2018, 01:07
 */

#ifndef MODELCOMPONENTMANAGER_IF_H
#define MODELCOMPONENTMANAGER_IF_H

class ModelComponentManager_if {
public:
    ModelComponentManager_if();
    ModelComponentManager_if(const ModelComponentManager_if& orig);
    virtual ~ModelComponentManager_if();
private:

};

#endif /* MODELCOMPONENTMANAGER_IF_H */

