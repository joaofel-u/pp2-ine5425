/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PickUp.h
 * Author: rlcancian
 *
 * Created on 03 de Junho de 2019, 15:15
 */

#ifndef PICKUP_H
#define PICKUP_H

class PickUp {
public:
    PickUp();
    PickUp(const PickUp& orig);
    virtual ~PickUp();
private:

};

#endif /* PICKUP_H */

