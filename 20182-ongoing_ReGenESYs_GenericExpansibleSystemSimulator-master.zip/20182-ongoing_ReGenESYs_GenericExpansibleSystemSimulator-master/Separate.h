/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Separate.h
 * Author: rlcancian
 *
 * Created on 03 de Junho de 2019, 15:14
 */

#ifndef SEPARATE_H
#define SEPARATE_H

class Separate {
public:
    Separate();
    Separate(const Separate& orig);
    virtual ~Separate();
private:

};

#endif /* SEPARATE_H */

