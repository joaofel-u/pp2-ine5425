/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   TestStatistics.h
 * Author: rafael.luiz.cancian
 *
 * Created on 30 de Agosto de 2018, 19:28
 */

#ifndef TESTSTATISTICS_H
#define TESTSTATISTICS_H

#include "GenesysApplication_if.h"

class TestStatistics : public GenesysApplication_if {
public:
    TestStatistics();
public:
    int main(int argc, char** argv);
};


#endif /* TESTSTATISTICS_H */

